---
title: Modem launch plan
folder: Projects/Modem
tags: [product, launch]
---

# Modem launch plan

Target launch is Q3. Sharia certification must complete before any public announcement.

## Milestones
- Beta to 50 users in month 1
- Certification review in month 2
- Public launch end of Q3

## Open questions
- Pricing tiers not finalized
- Support staffing for launch week
