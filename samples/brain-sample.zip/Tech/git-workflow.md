---
title: Git workflow
folder: Tech
tags: [git, reference]
---

# Git workflow

Branch from main, never commit directly. Rebase before merge to keep history linear.

```bash
git switch -c feature/x
git rebase main
```
