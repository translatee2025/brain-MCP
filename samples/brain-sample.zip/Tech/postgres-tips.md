---
title: Postgres tips
folder: Tech
tags: [database, reference]
---

# Postgres tips

Useful commands collected over time.

```sql
-- find slow queries
SELECT query, mean_exec_time
FROM pg_stat_statements
ORDER BY mean_exec_time DESC
LIMIT 10;
```

Always add an index before a large backfill, not after.
