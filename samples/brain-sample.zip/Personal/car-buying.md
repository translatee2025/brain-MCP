---
title: Car buying notes
folder: Personal
tags: [personal, decisions]
---

# Car buying notes

Leaning toward a white car: stays cooler in summer and resells more easily.

Budget ceiling is set. Prioritize reliability over features.
